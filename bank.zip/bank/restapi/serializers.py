from rest_framework import serializers
from .models import bank

class bankSerializer(serializers.ModelSerializer):

    class Meta:
        model = bank
        fields = ('ifsc','bank_id','branch','address','city','district','state','bank_name')