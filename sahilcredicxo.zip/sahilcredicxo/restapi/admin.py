from django.contrib import admin
from .models import bank

admin.site.register(bank)

# Register your models here.

